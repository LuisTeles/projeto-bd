create definer = root@localhost view vw_relatorio_viagens as
select `v`.`idMotorista`  AS `id_motorista`,
       `m`.`nome`         AS `nome_motorista`,
       `v`.`idVeiculo`    AS `id_veiculo`,
       `ve`.`placa`       AS `placa`,
       `ve`.`modelo`      AS `modelo`,
       `v`.`idRota`       AS `id_rota`,
       `r`.`destino`      AS `destino`,
       `r`.`distancia_km` AS `distancia_km`
from (((`frota_logistica`.`viagem` `v` join `frota_logistica`.`motorista` `m`
        on ((`m`.`id_motorista` = `v`.`idMotorista`))) join `frota_logistica`.`veiculo` `ve`
       on ((`ve`.`id_veiculo` = `v`.`idVeiculo`))) join `frota_logistica`.`rota` `r`
      on ((`r`.`id_rota` = `v`.`idRota`)));

